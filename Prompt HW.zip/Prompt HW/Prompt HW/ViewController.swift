//
//  ViewController.swift
//  Prompt HW
//
//  Created by Mike Lombardo on 7/6/16.
//  Copyright © 2016 Mike Lombardo. All rights reserved.
//

import UIKit

class PromptViewController: UIViewController {
    
    @IBOutlet weak var EnterBirthYearText: UITextField!
    @IBAction func verifyButton(sender: UIButton) {
    }
    
    @IBOutlet weak var resultLabel: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
         let enterBirthYear = <#value#>
    
    
//    func verifyAge (EnterBirthYear)= Int) {
//        if
//            let EnterBirthYearText <= 1995 {
//            print("You can drink, vote, and drive.")
//        }
//        else if EnterBirthYearText.text = Int >= 1998 {
//            print("You can vote and drive.")
//        }
//        else if EnterBirthYearText.text >= 2000 {
//            print("You can drive.")
//        }
//        else if EnterBirthYearText.text >= 2001 {
//            print("Wahhhh, Waaaaaaah, Waaaah!  Go take a nap you Baby!")
//        }
//    }
    
    
    //Bill Splitter


//    @IBOutlet weak var billTotal: UITextField!
//    @IBOutlet weak var tipPercentage: UITextField!
//    @IBOutlet weak var numberOfSplit: UITextField!
//    @IBAction func buttonCalculate(sender: UIButton) {
//        checkBillValues()
//    }
//    
//    @IBOutlet weak var resultTextBox: UILabel!
//    
//    func checkBillValues () {
//        if
//            let unwrappedBillTotal = billtotal.text,
//            let unwrappedTipPercentage = tipPercentage.text,
//            let unwerappedNumberofSplit = numberOfSplit.text
//        {
//            if let billTotal = Int(unwrappedBillTotal) where
//            if let tipPercentage + 1 = Int(unwrappedBillTotal) where
//            if let numberOfSplit = Int(unwerappedNumberofSplit) {
//                printText(/(unwrappedBillTotal * tipPercentage)/ numberofSplit)
//                
//            }
//  
    //Guess the Number
    
    @IBOutlet weak var numberInput: UITextField!
    @IBOutlet weak var hintText: UILabel!
    
    @IBAction func guessButton(sender: UIButton) {
        matchNumber()
    }

    let computerNumber = Int(arc4random_uniform(1...10))
    
    func matchNumber () {
        if
            let unwrappedNomputerNumber = numberInput.text,
            let numberInput.Text == computerNumber {
                print("You are correct!")
            }
        else if numberInput.text != computerNumber {
                print("Try Again!")
        }
        
    
        
        
   

}


    
        


