//
//  ItemsForSaleViewController.swift
//  Register3
//
//  Created by Mike Lombardo on 8/9/16.
//  Copyright © 2016 Mike Lombardo. All rights reserved.
//

import UIKit

protocol ItemsForSaleViewControllerDelegate: class {
    func userDidAddItem(item: ItemForSale)
    func userDidAddCustomItem(item: ItemForSale)
}


    class ItemsForSaleViewController: UIViewController {
       private var inventory = [ItemForSale]()

    
//    class AddItem: ItemForSale {
//        let name = String
//        let price = Double
//    } all buttons are class ItemForSale
    weak var delegate: ItemsForSaleViewControllerDelegate?
    
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        if segue.identifier == "maincellidentifier" {
//            if let customItemViewController = segue.destinationViewController as? CustomItemViewController {
//                customItemViewController.delegate = ItemsForSaleViewControllerDelegate
//                dismissViewControllerAnimated(true, completion: nil)
//                            if let indexPath = tableView.indexPathForSelectedRow {
//                                inventory = inventory[indexPath.row]
//                                customItemViewController.inventory = ItemForSale
//            }
//        }
    

    @IBAction func button1Add(sender: UIButton) {
        delegate?.userDidAddItem(ItemForSale (name: "Mac Book", price: 1499.99))
        dismissViewControllerAnimated(true, completion: nil)

    }
    @IBAction func button2Add(sender: UIButton) {
        delegate?.userDidAddItem(ItemForSale (name: "iPhone", price: 999.99))
        dismissViewControllerAnimated(true, completion: nil)

    }

    @IBAction func button3Add(sender: AnyObject) {
        delegate?.userDidAddItem(ItemForSale (name: "Beats Headphones", price: 59.99))
        dismissViewControllerAnimated(true, completion: nil)

    }

    @IBAction func button4Add(sender: AnyObject) {
    }

    
    @IBAction func cancelAdd(sender: UIBarButtonItem) {
        dismissViewControllerAnimated(true, completion: nil)
        }

    }


extension ItemsForSaleViewController: CustomItemViewControllerDelegate {
    func userDidAddCustomItem(item: ItemForSale) {
         var inventory = [ItemForSale]()
        inventory.append(item)
//        tableView.reloadData()
   }
}