//
//  itemForSale.swift
//  Register3
//
//  Created by Mike Lombardo on 8/4/16.
//  Copyright © 2016 Mike Lombardo. All rights reserved.
//

import Foundation

class ItemForSale {
    let name: String
    let price: Double
    
    init(name: String, price: Double) {
        self.name = name
        self.price = price
    }
}
