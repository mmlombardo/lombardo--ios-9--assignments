//
//  ViewController.swift
//  Register3
//
//  Created by Mike Lombardo on 8/4/16.
//  Copyright © 2016 Mike Lombardo. All rights reserved.
//

import UIKit

class RegisterTableViewController: UITableViewController {
    
    private var inventory = [ItemForSale]()

    @IBOutlet var registerTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        let itemsForSale = [
//            ItemForSale (name: "Mac Book", price: 1499.99),
//            ItemForSale (name: "iPhone", price: 999.99),
//            ItemForSale (name: "Beats Headphones", price: 59.99)
//        ]
//        
//        inventory.appendContentsOf(itemsForSale)
  
    }
    
    @IBAction func addItemForSaleButton(sender: UIBarButtonItem) {
        let storyboard = UIStoryboard(name: "ItemsForSaleStoryboard", bundle: nil)
        
        if
            let itemsForSaleNavigationController =
                storyboard.instantiateViewControllerWithIdentifier("ItemsForSaleNavigationController") as? UINavigationController,
            let itemsForSaleViewController = itemsForSaleNavigationController.topViewController as? ItemsForSaleViewController {
            
            itemsForSaleViewController.delegate = self
            
            presentViewController(itemsForSaleNavigationController, animated: true) {
                print("Finished")
            }
        }
        
        
    }
    
 
    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return inventory.count
    
}
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("maincellidentifier", forIndexPath: indexPath)
        
        let itemForSale = inventory[indexPath.row]
        cell.textLabel?.text = itemForSale.name
        cell.detailTextLabel?.text = String(itemForSale.price)
        //to make a double into a String
        return cell
    }
    

}

//
//func subTotalContents() {
//    inventory.count 
//}

extension RegisterTableViewController: ItemsForSaleViewControllerDelegate {
    func userDidAddItem(item: ItemForSale) {
        inventory.append(item)
        tableView.reloadData()
    }
}

extension RegisterTableViewController: CustomItemViewControllerDelegate {
    func userDidAddCustomItem(item: ItemForSale) {
        inventory.append(item)
        tableView.reloadData()
    }
}

extension RegisterTableViewController: CartContentsViewControllerDelegate {
    func userHasItemsInCart(item: ItemForSale) {
        
    }
}

