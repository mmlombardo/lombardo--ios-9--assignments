//
//  CartContentsViewController.swift
//  Register3
//
//  Created by Mike Lombardo on 8/15/16.
//  Copyright © 2016 Mike Lombardo. All rights reserved.
//

import UIKit

protocol CartContentsViewControllerDelegate: class {
    func userHasItemsInCart(item: ItemForSale)
//        let numberOfItemsLabel.text = inventory.append
//    return inventory.append
    
}

//class Subtotal {
//    let inventory.sum: Int
//    func Addition() -> Int {
//        return inventory.sum
//    }
//    
//}

//class CartContentsViewController: UIViewController {
//     var subtotal = Subtotal!
//    @IBOutlet weak var numberOfItemsLabel: UILabel!
//    
//}

