//
//  CustomItem.swift
//  Register3
//
//  Created by Mike Lombardo on 8/9/16.
//  Copyright © 2016 Mike Lombardo. All rights reserved.
//

import UIKit

protocol CustomItemViewControllerDelegate: class {
    func userDidAddCustomItem(item: ItemForSale)
}

class CustomItemViewController: ItemsForSaleViewController {

class CustomItemViewController:  UIViewController {
    
    
    weak var delegate: CustomItemViewControllerDelegate?
    
    @IBOutlet weak var customNameField: UITextField!
    @IBOutlet weak var customPriceField: UITextField!

    @IBAction func customAddButton(sender: UIBarB uttonItem) {
        guard
            let name = customNameField.text,
            let priceText = customPriceField.text,
            let price = Double(priceText)
            else
        {
            return
        }
        
        let itemForSale = ItemForSale(name:customNameField.text!, price: Double(customPriceField.text!)!)
        navigationController?.popViewControllerAnimated(true)
        dismissViewControllerAnimated(true, completion: nil)

        }
    }
}

//let storyboard = UIStoryboard(name: "ItemsForSaleStoryboard", bundle: nil)
//
//    let itemsForSaleNavigationController =
//    storyboard.instantiateViewControllerWithIdentifier("ItemsForSaleNavigationController") as? UINavigationController,
//    let itemsForSaleViewController = itemsForSaleNavigationController.topViewController as? ItemsForSaleViewController {
//    
//    itemsForSaleViewController.delegate = self
//    
//    presentViewController(itemsForSaleNavigationController, animated: true) {
//        print("Finished")
