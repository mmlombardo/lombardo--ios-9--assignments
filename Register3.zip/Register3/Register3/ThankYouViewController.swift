//
//  ThankYouViewController.swift
//  Register3
//
//  Created by Mike Lombardo on 8/15/16.
//  Copyright © 2016 Mike Lombardo. All rights reserved.
//

import UIKit

//protocol ThankYouViewControllerDelegate:class {
//    }

//class ThankYouViewController: UIViewController {
//    var ChangeToGive: ChangeGiven
//    
//}

//extension RegisterTableViewController: ThankYouViewControllerDelegate {
//    func calculateChangeToGive(item: ChangeGiven) {
//
//    }
//}